// number literals
// operators

let x = 1;
let y = "1";
console.log(1+x+y) 
alert(1+x+y)
// When 1 isnt combind with quotations it does not add numbers together like 1+1=2
// instead it will be 1+1=11 Thats only if you use quotations
let a = x;
x = y;
y = a;
/* When commanding a to replace with x, x now becomes a. You are swapping around variables

*/
let mhy1=document.getElementById("myh1"); // function call
myh1.innerHTML = 'I robot:"hi\nRobot'; // test data, aka string

